def onShutdown(session):
	from exchange.ui.init import initializeSession
		
	session.custom.navigation = endOfSession().get('navigation', {'menu': None})