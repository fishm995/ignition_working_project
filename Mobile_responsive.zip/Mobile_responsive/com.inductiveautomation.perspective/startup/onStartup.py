def onStartup(session):
	from exchange.ui.init import initializeSession
	
	session.custom.navigation = initializeSession().get('navigation', {'menu': 'home'})