UPDATE  exuiweb_workorders 
SET  status_id= :status,  update_date = :update_date 
WHERE  id = :id ;