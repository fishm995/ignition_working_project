UPDATE  exuiweb_nav_menu
SET  in_use = :in_use
WHERE  id = :id;