UPDATE  exuiweb_nav_menu
SET  label = :label 
WHERE  id = :id;