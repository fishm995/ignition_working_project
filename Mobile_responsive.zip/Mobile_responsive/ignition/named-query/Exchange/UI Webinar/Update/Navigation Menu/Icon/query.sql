UPDATE  exuiweb_nav_menu
SET  icon = :icon
WHERE  id = :id;