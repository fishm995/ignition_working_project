UPDATE  exuiweb_workorders
SET  complete_date= :complete_date 
WHERE  id = :id ;