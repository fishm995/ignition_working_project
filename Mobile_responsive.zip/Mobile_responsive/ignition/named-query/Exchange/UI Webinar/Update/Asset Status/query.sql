UPDATE  exuiweb_assets
SET  status= :status 
WHERE  id = :id ;