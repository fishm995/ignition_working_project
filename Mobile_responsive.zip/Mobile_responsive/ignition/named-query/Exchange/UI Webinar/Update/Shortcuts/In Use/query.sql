UPDATE  exuiweb_home_shortcuts
SET  path = :path 
WHERE  id = :id;