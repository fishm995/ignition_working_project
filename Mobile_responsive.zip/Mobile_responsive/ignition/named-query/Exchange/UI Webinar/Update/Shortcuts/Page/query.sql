UPDATE  exuiweb_home_shortcuts
SET  shortcut_page = :page
WHERE  id = :id;