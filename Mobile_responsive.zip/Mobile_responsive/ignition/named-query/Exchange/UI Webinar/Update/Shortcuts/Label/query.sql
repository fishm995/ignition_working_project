UPDATE  exuiweb_home_shortcuts
SET  label = :label 
WHERE  id = :id;