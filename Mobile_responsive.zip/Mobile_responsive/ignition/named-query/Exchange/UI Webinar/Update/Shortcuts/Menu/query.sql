UPDATE  exuiweb_home_shortcuts
SET  shortcut_menu = :menu
WHERE  id = :id;