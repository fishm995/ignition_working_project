UPDATE  exuiweb_tasks
SET  status= :status 
WHERE  id = :id ;