UPDATE  exuiweb_assets
SET  is_deleted = :is_deleted
WHERE  id = :id ;