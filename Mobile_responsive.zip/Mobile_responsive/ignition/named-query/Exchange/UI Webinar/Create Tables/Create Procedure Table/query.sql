CREATE TABLE IF NOT EXISTS exuiweb_procedure(
	id INTEGER PRIMARY KEY AUTOINCREMENT,
	name varchar(255) NOT NULL,
	description varchar(255) NULL,
	filebytes LONGBLOB NULL,
	asset_id integer,
	FOREIGN KEY (asset_id) REFERENCES exuiweb_assets(id)
	);