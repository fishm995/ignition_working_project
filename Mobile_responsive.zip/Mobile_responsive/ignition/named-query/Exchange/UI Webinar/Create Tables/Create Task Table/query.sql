CREATE TABLE IF NOT EXISTS exuiweb_tasks(
	id INTEGER PRIMARY KEY AUTOINCREMENT,
	name varchar(255) NOT NULL,
	description varchar(255) NOT NULL,
	create_date datetime NULL,
	status varchar(255) NOT NULL,
	workorder_id integer,
	estimated_hours real,
	complexity varchar(255),
	FOREIGN KEY (workorder_id) REFERENCES exuiweb_workorders(id)
	);