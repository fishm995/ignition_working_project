CREATE TABLE IF NOT EXISTS exuiweb_workorder_history(
	id INTEGER PRIMARY KEY AUTOINCREMENT,
	firstname varchar(255) NULL,
	lastname varchar(255) NULL,
	updated datetime NOT NULL,
	message varchar(255) NULL,
	workorder_id integer,
	FOREIGN KEY (workorder_id) REFERENCES exuiweb_workorders(id)
	);