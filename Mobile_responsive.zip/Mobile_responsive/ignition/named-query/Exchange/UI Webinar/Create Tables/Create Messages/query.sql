CREATE TABLE IF NOT EXISTS exuiweb_messages(
	id INTEGER PRIMARY KEY AUTOINCREMENT,
	label varchar(255) NOT NULL,
	show integer Null
	);