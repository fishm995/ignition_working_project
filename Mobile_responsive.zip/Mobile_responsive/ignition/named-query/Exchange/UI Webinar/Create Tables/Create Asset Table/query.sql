CREATE TABLE IF NOT EXISTS exuiweb_assets(
	id INTEGER PRIMARY KEY AUTOINCREMENT,
	name varchar(255) NOT NULL,
	description varchar(255) NOT NULL,
	asset_type varchar(255) NULL,
	create_date datetime NULL,
	license varchar(255) NULL,
	location varchar(255) NULL,
	status integer Null,
	sub_asset integer Null,
	is_deleted INTEGER DEFAULT 0
	);