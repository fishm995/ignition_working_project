CREATE TABLE IF NOT EXISTS exuiweb_workorders(
	id INTEGER PRIMARY KEY AUTOINCREMENT,
	name varchar(255) NOT NULL,
	description varchar(255) NOT NULL,
	first_name varchar(255) NULL,
	last_name varchar(255) NULL,
	location varchar(255) NULL,
	author_firstname varchar(255) NULL,
	author_lastname varchar(255) NULL,
	role varchar(255) NULL,
	create_date datetime NULL,
	due_date datetime NULL,
	complete_date datetime NULL,
	update_date datetime NULL,
	status_id integer,
	priority varchar(255) NULL,
	asset_id integer,
	FOREIGN KEY (asset_id) REFERENCES exuiweb_assets(id)
	FOREIGN KEY (status_id) REFERENCES exuiweb_wostatus(id)
	);