CREATE TABLE IF NOT EXISTS exuiweb_wostatus(
	id integer PRIMARY KEY NOT NULL,
	name varchar(255) NOT NULL
	);