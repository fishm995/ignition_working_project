CREATE TABLE IF NOT EXISTS exuiweb_home_shortcuts (
	id INTEGER PRIMARY KEY AUTOINCREMENT
	, label VARCHAR(255)
	, shortcut_menu VARCHAR(255)
	, shortcut_page VARCHAR(255)
	, in_use INTEGER DEFAULT 1
);