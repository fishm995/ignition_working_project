INSERT INTO  exuiweb_workorder_history (firstname,  lastname,  message,  updated,  workorder_id)
VALUES ( :firstname , :lastname,  :message , :updated,  :workorder_id )