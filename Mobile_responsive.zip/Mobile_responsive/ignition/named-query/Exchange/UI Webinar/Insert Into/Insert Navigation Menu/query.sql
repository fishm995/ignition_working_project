INSERT INTO exuiweb_nav_menu (label, icon)
VALUES (:label, :icon)