INSERT INTO exuiweb_home_shortcuts (label, shortcut_menu, shortcut_page)
VALUES (:label, :menu, :page)