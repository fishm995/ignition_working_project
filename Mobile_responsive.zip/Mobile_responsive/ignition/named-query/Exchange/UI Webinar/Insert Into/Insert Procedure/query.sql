INSERT INTO  exuiweb_procedure  ( name,  description,  filebytes,  asset_id )
VALUES ( :name , :description , :filebytes , :asset_id )