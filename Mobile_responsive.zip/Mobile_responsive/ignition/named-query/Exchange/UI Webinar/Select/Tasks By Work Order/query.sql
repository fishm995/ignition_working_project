SELECT * From  exuiweb_tasks 
where  workorder_id =:workorder_id