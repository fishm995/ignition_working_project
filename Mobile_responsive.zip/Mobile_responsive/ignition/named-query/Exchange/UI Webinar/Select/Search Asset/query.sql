SELECT *
FROM  exuiweb_assets
WHERE (name like '%' || :term || '%' OR description like '%' || :term || '%' OR id like '%' || :term || '%') AND (length(:term)>0)