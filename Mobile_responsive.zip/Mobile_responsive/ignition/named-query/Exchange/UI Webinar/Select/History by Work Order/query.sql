SELECT * from  exuiweb_workorder_history
Where  workorder_id = :workorder_id 
order by  updated desc