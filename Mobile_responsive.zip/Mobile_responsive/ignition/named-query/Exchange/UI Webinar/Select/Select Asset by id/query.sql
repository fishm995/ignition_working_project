SELECT * From  exuiweb_assets 
Where id=:id