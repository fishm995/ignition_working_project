SELECT COALESCE(tbl.name, "Unspecified") AS "status"
FROM exuiweb_wostatus AS tbl
WHERE tbl.id = :id