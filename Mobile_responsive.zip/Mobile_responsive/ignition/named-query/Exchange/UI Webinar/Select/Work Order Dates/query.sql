SELECT distinct date(substr(due_date, 0, 11), 'unixepoch') as 'due_date'
FROM  exuiweb_workorders 
ORDER BY due_date