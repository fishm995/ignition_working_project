Select * From  exuiweb_assets 
where id =:id