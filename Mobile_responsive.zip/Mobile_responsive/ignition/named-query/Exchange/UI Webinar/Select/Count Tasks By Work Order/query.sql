SELECT count(id) as "num" from  exuiweb_tasks 
where  workorder_id =:workorder_id
