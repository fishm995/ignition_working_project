SELECT count(id) as "num" from  exuiweb_tasks 
