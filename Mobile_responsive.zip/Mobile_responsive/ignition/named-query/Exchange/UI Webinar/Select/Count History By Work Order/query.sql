SELECT count(id) as "num" from  exuiweb_workorder_history 
where  workorder_id =:workorder_id
