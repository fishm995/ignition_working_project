SELECT DISTINCT asset_type 
FROM exuiweb_assets