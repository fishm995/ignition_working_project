SELECT 
	tbl.id
	, False AS 'selected'
FROM exuiweb_assets AS tbl
WHERE tbl.is_deleted = 1