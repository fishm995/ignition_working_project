SELECT
	tbl.label
	, tbl.icon
FROM exuiweb_nav_menu AS tbl
WHERE tbl.in_use = 1;