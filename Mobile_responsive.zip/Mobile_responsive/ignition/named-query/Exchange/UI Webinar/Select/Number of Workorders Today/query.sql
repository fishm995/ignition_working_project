SELECT count(id)
FROM  exuiweb_workorders
WHERE status_id != 4 AND date(substr(due_date, 0, 11), 'unixepoch') = date()