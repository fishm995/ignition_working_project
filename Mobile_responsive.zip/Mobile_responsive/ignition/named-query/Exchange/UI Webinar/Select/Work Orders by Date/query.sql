SELECT *
FROM exuiweb_workorders
WHERE date(substr(due_date, 0, 11), 'unixepoch') = :due_date
ORDER BY due_date