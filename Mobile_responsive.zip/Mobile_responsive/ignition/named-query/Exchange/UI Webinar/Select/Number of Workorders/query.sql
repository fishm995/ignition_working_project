SELECT count(id)
FROM  exuiweb_workorders
WHERE status_id != 4