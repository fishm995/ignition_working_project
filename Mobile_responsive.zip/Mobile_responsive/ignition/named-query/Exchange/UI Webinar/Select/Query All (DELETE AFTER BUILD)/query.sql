SELECT *
FROM  {table}  
