SELECT *
FROM exuiweb_workorders
WHERE asset_id = :asset_id
ORDER BY due_date