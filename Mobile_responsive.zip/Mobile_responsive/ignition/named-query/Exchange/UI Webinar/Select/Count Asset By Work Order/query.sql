SELECT count(id) as "num" from  exuiweb_workorders 
where  asset_id= :asset_id 

