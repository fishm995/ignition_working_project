Select  id, name,  description, status
From  exuiweb_assets 
where location=:location
	AND is_deleted = 0;