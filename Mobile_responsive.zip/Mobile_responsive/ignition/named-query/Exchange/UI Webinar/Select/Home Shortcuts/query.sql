SELECT 
	tbl.label
	, tbl.shortcut_menu
	, tbl.shortcut_page
FROM exuiweb_home_shortcuts AS tbl
WHERE tbl.in_use = 1