SELECT 
	{columns}
	, 'exuiweb_assets' AS 'tableName'
FROM exuiweb_assets
WHERE id = :id;