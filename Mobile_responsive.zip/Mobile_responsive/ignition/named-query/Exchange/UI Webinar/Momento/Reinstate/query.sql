UPDATE {tableName}
SET {statement} 
WHERE  id = :id ;