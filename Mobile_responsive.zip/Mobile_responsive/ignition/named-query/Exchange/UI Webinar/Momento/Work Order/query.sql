SELECT 
	{columns}
	, 'exuiweb_workorders' AS 'tableName'
FROM exuiweb_workorders
WHERE id = :id;