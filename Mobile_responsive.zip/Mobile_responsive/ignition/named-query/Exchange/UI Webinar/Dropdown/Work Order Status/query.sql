SELECT 
	tbl.id
	, tbl.name
FROM exuiweb_wostatus AS tbl