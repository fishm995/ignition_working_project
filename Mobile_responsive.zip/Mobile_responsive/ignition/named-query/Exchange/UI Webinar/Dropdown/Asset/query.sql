SELECT 
	tbl.id AS "value"
	, tbl.name AS "label"
FROM exuiweb_assets AS tbl