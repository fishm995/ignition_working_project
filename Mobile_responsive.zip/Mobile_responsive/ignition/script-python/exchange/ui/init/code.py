def initializeSession():
	"""Initial session properties to initialize for the perspective session"""
	props = {
		'navigation': {'menu': 'home'}
		}
	return props
	
def endOfSession():
	"""Initial session properties to initialize for the perspective session"""
	props = {
		'navigation': {'menu': None}
		}
	return props
	
def initializeTables(logOnExists=True):
	"""Initialize database tables (SQLITE db)"""
	cxn = system.db.getConnectionInfo()
	logger = system.util.getLogger('{} Table Setup'.format(system.project.getProjectName()))
	if cxn.getRowCount() == 1:
		if cxn.getValueAt(0, 'DBType').upper() == 'SQLITE':
			toBuild = {
				('wostatus', 'Create WO Status Table')
				, ('assets', 'Create Asset Table')
				, ('nav_menu', 'Create Navigation Menu Table')
				, ('workorders', 'Create Workorder Table')
				, ('tasks', 'Create Task Table')
				, ('workorder_history', 'Create WO History Table')
				, ('home_shortcuts', 'Create Shortcuts Table')
				, ('procedure', 'Create Procedure Table')
				}
			
			for tbl, query in toBuild:
				tableName = TableCreator.tableName(tbl)
				system.db.runNamedQuery(TableCreator.nQuery(query))
				logger.info("Table '{}' created".format(tableName))
		else:
			logger.info('Default database must be SQLITE')
	else:
		logger.info('No default database')
	return None
		
class TableCreator:
	"""Table Creator helper class"""
	PATH = 'Exchange/UI Webinar/Create Tables/{}'
	TABLE = 'exuiweb_{}'
	
	@classmethod
	def nQuery(cls, *args):
		"""Get the named query path from the input args"""
		return cls.PATH.format('/'.join(args))
		
	@classmethod
	def tableName(cls, tbl):
		"""Get the table name format"""
		return cls.TABLE.format(tbl)