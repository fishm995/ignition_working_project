from exchange.ui import util
class Momento:
	"""Momento pattern to facilitate undo actions"""
	PATH = 'Exchange/UI Webinar/Momento/{}'
	RESERVED = {'tableName', 'id'}
	TYPE_MAP = {str: "'{}'", int: "{}", float: "{}"}
	
	@classmethod
	def snapshot(cls, objectType, objectID, *columns):
		"""Take a snapshot/momento of an objects state in order to re-instate object if needed.
		
		Args:
			objectType: path to the named query that will return the snapshot/momento
			objectID: id of the object to capture
		Returns:
			momento object that can be used to reset the state of the object back to
			the initial state
		"""
		params = {'id': objectID, 'columns': ', '.join(['id'] + [str(_) for _ in columns])}
		results = system.db.runNamedQuery(cls.PATH.format(objectType), params)
		results = util.datasetToDict(results)
		if len(results) == 1:
			momento = {key: value for key, value in results[0].items()}
		else:
			momento = None
		return momento
	
	@classmethod
	def reinstate(cls, momento):
		"""Reinstante the object to the state of the momento
		
		Args:
			momento: momento object needed to reinstate an object to it's former state
		Returns:
			bool of reinstate status
		"""
		statement = ', '.join([cls.getReinstateSet(key, value) for key, value in momento.items() if key not in cls.RESERVED])
		params = {
			'tableName': momento.get('tableName')
			, 'id': momento.get('id', 0)
			, 'statement': statement
			}
		results = system.db.runNamedQuery(cls.PATH.format('Reinstate'), params)
		return results
	
	@classmethod
	def getReinstateSet(cls, key, value):
		"""Get the SQL statement string for the associated key, value pair coming from momenot object"""
		typeFormat = cls.TYPE_MAP.get(type(value), "'{}'").format(value)
		return "{}={}".format(key, typeFormat)