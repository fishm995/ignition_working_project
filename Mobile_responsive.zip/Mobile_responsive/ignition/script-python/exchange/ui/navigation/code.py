from exchange.ui import query

def getMenu():
	"""Return the list of dicts for the navigation menu"""
	menu = query.menuTable()
	return menu
	
def navTo(navKey, *args):
	"""Send the navigation menu to update the main screen's navigation
	
	Args:
		navKey: url landing
		params: additional url params to navigate to
	Returns:
		None
	"""
	page = '/{}'.format(navKey if navKey != 'home' else '')
	if args:
		page = '/'.join([page, '/'.join(args)])
	
	system.perspective.navigate(page=page)
	return None
	
def swapTo(view, params={}):
	"""Swap to a different view in the Framework/Page folder"""
	viewPath = 'Exchange/UI Webinar/Framework/Page/{}'.format(view)
	system.perspective.navigate(view=viewPath, params=params)
	return None
	
def convertToNavKey(value):
	"""Consistent formatting for the navigation key --> web page"""
	return value.lower().replace(' ', '-')
	
def convertFromNavKey(navKey):
	"""Format value from navKey to a header format"""
	return navKey.replace('-', ' ').capitalize()
	
def getShortcuts():
	"""Return the list of shortcuts for the home page"""
	shortcut = query.shortcutTable()
	return [toShortcutObject(s) for s in shortcut]
	
def toShortcutObject(item):
	"""Configure shortcut dict to match view params
	
	Args:
		item: row returned from shortcut named query
	Returns:
		dict
	"""
	obj = {'label': item.get('label', ''), 'navTo': {'menu': item.get('shortcut_menu', ''), 'page': item.get('shortcut_page', '')}, 'quantity': {'unit': '', 'value': -1}}
	return obj
	