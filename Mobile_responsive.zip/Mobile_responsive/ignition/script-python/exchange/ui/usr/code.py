import random
def getUserDropdown(src='default'):
	"""Get a list of users from the default usersource to display in a dropdown"""
	toDropdown = lambda u: {'label': "{} {}".format(u.get('firstname'), u.get('lastname')), 'value': u.get('username')}
	return map(toDropdown, system.user.getUsers(src))
	
def getRandomUser(src='default'):
	"""Get a list of users from the default usersource to display in a dropdown"""
	return random.choice(system.user.getUsers(src))