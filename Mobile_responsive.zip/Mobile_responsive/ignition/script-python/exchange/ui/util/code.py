def datasetToDict(dataset):
	"""Convert ignition dataset into a dictionary object"""
	headers = dataset.getColumnNames()
	return [{header: dataset.getValueAt(row, header) for header in headers} for row in range(dataset.getRowCount())]
	
def colorize(label, numChars=1):
	"""Generate a color from the input label
	
	Args:
		label: text to convert to color
		numChars: number of chars to use for the color (default: 1)
	Returns:
		hex color
	"""
	colorize = sum(ord(c) for c in label.lower()[(-1*numChars):])
	color = colorize/(122.0*numChars)
	r = int(255*(1-color))
	g = int(255*color)
	b = 255
	return '#{:X}{:X}{:X}'.format(r, g, b)

def randomColorize():
	"""Generate a random color from the internal list of colors"""
	import random
	colors = '#A855F7', '#6366F1', '#0EA5E9', '#14B8A6', '#22C55E', '#F97316'
	return random.choice(colors)
	
def getUserDropdown(src='default'):
	"""Get a list of users from the default usersource to display in a dropdown"""
	toDropdown = lambda u: {'label': "{} {}".format(u.get('firstname'), u.get('lastname')), 'value': u.get('username')}
	return map(toDropdown, system.user.getUsers(src))