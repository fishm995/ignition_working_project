class _AbstractDummyData:
	_prepQuery = 'INSERT OR REPLACE INTO {} ({}) VALUES ({})'
	_table = ''
	_columns = []
	_data = []
	_order = -1
	
	@classmethod
	def getPrepQueryStatement(cls):
		"""Prep query statement for the data insert"""
		return cls._prepQuery.format(cls._table, ', '.join(cls._columns), ', '.join(['?']*len(cls._columns)))
	@classmethod
	def getData(cls):
		"""Return class data prop"""
		return cls._data
		
	@classmethod
	def toDropdown(cls):
		"""Return formatting for a dropdown component"""
		return {'label': cls.label(), 'value': cls._table}
		
	@classmethod
	def isMyTable(cls, tbls):
		"""Return true if input table name is the same as the class"""
		return cls._table in tbls
		
	@classmethod
	def label(cls):
		"""Get data class label"""
		return cls._table.split('exuiweb_')[-1].replace('_', ' ').title()
		
	@classmethod
	def getOrder(cls):
		"""Get Order Value"""
		return cls._order