import inspect
from exchange.ui.data import data
from exchange.ui.data.interface import _AbstractDummyData

def load(tbls=[], loadAll=False):
	"""Load the data into the db tables based on table name input"""
	for obj in getAvailableDataClasses():
		if obj.isMyTable(tbls) or loadAll:
			loadDummyData(obj)
	return None
	
def loadDummyData(dataClass):
	"""Load dummy data into the db based on the input Dummy Data child class"""
	logger = system.util.getLogger('ui-webinar Dummy Data')
	if issubclass(dataClass, _AbstractDummyData):
		prepStatement = dataClass.getPrepQueryStatement()
		for data in dataClass.getData():
			system.db.runPrepUpdate(prepStatement, list(data))
		logger.info('{} data loaded'.format(dataClass._table))
	else:
		logger.info('Cannot load data from input class')
		
def getDropdown():
	"""Get the dropdown options to choose from in the config page"""
	return [c.toDropdown() for c in getAvailableDataClasses()]
	
def getAvailableDataClasses():
	"""Get the available data class containers that can be loaded"""
	isMember = lambda member: inspect.isclass(member) and member.__module__ == 'data'
	dc = [obj for name, obj in inspect.getmembers(data, isMember)]
	dc.sort(key=lambda x: x.getOrder())
	return dc