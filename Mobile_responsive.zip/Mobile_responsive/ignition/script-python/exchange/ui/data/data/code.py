from exchange.ui.data.interface import _AbstractDummyData

class HomeShortcuts(_AbstractDummyData):
	_table = 'exuiweb_home_shortcuts'
	_columns = ['id', 'label', 'shortcut_menu', 'shortcut_page', 'in_use']
	_order = 10
	_data = [
		[1, 'Settings', '', '', 1]
		, [2, 'Support', '', '', 1]
		, [3, 'Recently Deleted', '', 'Recently Deleted', 1]
		]
		
class NavMenu(_AbstractDummyData):
	_table = 'exuiweb_nav_menu'
	_columns = ['id', 'label', 'icon', 'in_use']
	_order = 10
	_data = [
		[1, 'Home', 'home', 1]
		, [2, 'Work Orders', 'assignment', 1]
		, [3, 'Assets', 'apps', 1]
		]

class Status(_AbstractDummyData):
	_table = 'exuiweb_wostatus'
	_columns = ['id', 'name']
	_order = 10
	_data = [
		[0, 'Active'], [1, 'Inactive']
		, [2, 'In Progress'], [3, 'Pause']
		, [4, 'Complete'], [5, 'Not Started']
		, [6, 'Expired']
		]

class Assets(_AbstractDummyData):
	_table = 'exuiweb_assets'
	_columns = ['id', 'asset_type', 'create_date', 'description', 'is_deleted', 'license', 'location', 'name', 'status', 'sub_asset']
	_order = 20
	_data = [
		[1, "Hardware", 1675213517000, "5 Ton Vehicle Jack", 1, "12345", "Maintenance", "Car Jack", 0, None]
		, [2, "Leased Hardware", 1675213517000, "Local Trash Compactor", 0, "ABC123", "Maintenance", "Trash Compactor", 0, None]
		, [3, "Software", 1675213517000, "Inductive Automation SCADA", 0, "A1-B2C3", "Headquarters", "Ignition", 0, None]
		, [4, "Department", 1675213517000, "Storehouse", 0, "X1-Y2K", "Storage Building A", "Parts Inventory System", 0, None]
		, [5, "NA", 1675213517000, "Garbage Collection", 0, "1456", "Maintenance", "Garbage", 0, None]
		]
	
class Procedure(_AbstractDummyData):
	_table = 'exuiweb_procedure'
	_columns = ['id', 'asset_id', 'description', 'filebytes', 'name']
	_order = 100
	_data = []
	
class Tasks(_AbstractDummyData):
	_table = 'exuiweb_tasks'
	_order = 40
	_columns = ['id', 'name', 'description', 'create_date', 'status', 'workorder_id', 'estimated_hours', 'complexity']
	_data = [
		[1, "Elevate Vehicle", "Utilize Floor Jack to raise vehicle", 1674570900000, 4, 3, 0.25, "Simple, Easy"]
		, [2, "Remove Lug Nuts", "Remove Lug Nuts from wheel", 1674570900000, 2, 3, 0.15000000596046448, "Simple, Easy"]
		, [3, "Remove Wheel From Vehicle", "Pull Wheel Off of Vehicle", 1674570900000, 5, 3, 0.15000000596046448, "Simple, Easy"]
		, [4, "Remove Tire", "Remove Tire From Rim", 1674570900000, 5, 3, 0.25, "Simple, Easy"]
		, [5, "Repair S-Trap", "Replace S-Trap on Sink", 1674499800000, 3, 1, 3.5, "Simple, Easy"]
		, [6, "Replace Door Hinges", "", 1674460800000, 4, 2, 8, "Complex, Difficult"]
		, [7, "Check Freon Level", "Check/Refill Freon", 1672647600000, 4, 4, 0., "Simple, Easy"]
		, [8, "Gather Waste Bags", "", 1672646460000, 4, 6, 0.05, "Simple, Easy"]
		, [9, "Replace Bag", "Replace Waste Bag in Trash Can", 1672646700000, 4, 6, 0.10000000149011612, "Simple, Easy"]
		, [10, "Place Waste In Trash Compactor", "", 1672646820000, 4, 6, 0.20000000298023224, "Simple, Easy"]
		]
	
class WorkOrder(_AbstractDummyData):
	_table = 'exuiweb_workorders'
	_order = 30
	_columns = ['id', 'name', 'description', 'first_name', 'last_name', 'location', 'create_date'
		, 'due_date', 'complete_date', 'update_date', 'status_id', 'priority', 'asset_id'
		, 'author_firstname', 'role', 'author_lastname']
	_data = [
		[1, "Leaky Pipe", "Fix The Leak", "Michael", "Coral", "San Diego, CA", 1674499800000, 1674518400000, None, 1674731378657, 4, "High", 5, "Mark", "admin", "Maintainer"]
		, [2, "Replace Door", "Swap out hinges", "Rae", "Bryan", "San Diego, CA", 1674460800000, 1674547200000, None, 1674674734869, 0, "High", 5, "Mark", "admin", "Maintainer"]
		, [3, "Fix Tire", "Patch Hole in Tire", "Sally", "Fire", "San Diego, CA", 1673856000000, 1674806400000,  None, 1674664239940, 2, "Low", 1, "Mark", "Admin", "Maintainer"]
		, [4, "Repair AC", "Check Coolant Level", "John", "Smith", "Folsom, CA", 1672646400000, 1672819200000, None, 1675183763127, 1, "Medium", 5, "Mark", "Admin", "Maintainer"]
		, [5, "Take Out Trash", "Empty Waste Bins", "John", "Smith", "Folsom, CA", 1672646400000, 1672819200000, None, 1674664187751, 4, "Low", 3, "Mark", "Admin", "Maintainer"]
		, [6, "ABC-XYZ-123", "Work Order Description", "Madiha", "Javed", "Headquarters", 1674667650593, 1674839764212, None, 1674670250280, 2, "High", 1,  "Conner", "Administrator", "Futa"]
		, [7, "UI WO", "UI Work Order being created", "Ryan", "Zakskorn", "Site A", 1674668215876, 1675186560000, None, 1674669827290, 0, "High", 4, "Conner", "Administrator", "Futa"]
		, [8, "test", "test", "Ray", "Sensenbach", "Folsom, CA", 1675172863292, 1675345654735, None, 1675172863292, 0, "High", 1, "Ray", "UI Admin, Administrator", "Sensenbach"]
	]
	
class WorkOrderHistory(_AbstractDummyData):
	_table = 'exuiweb_workorder_history'
	_order = 40
	_columns = ['id', 'firstname', 'lastname', 'updated', 'message', 'workorder_id']
	_data = [
		[1, "Trina ", "Davis", 1672857740000, "\u003cb\u003eCreated\u003c/b\u003e the Work Order", 1]
		, [2, "Ayhan", "Seven", 1673462540000, "\u003cp\u003e\u003cb\u003eCommented\u003c/b\u003e on Work Order\u003c/p\u003e\u003cfont size\u003d\"-8\"\u003e\"Sit accumsan vel lacus faucibus volutpat cum. Fringilla tincidunt bibendum interdum morbi volutpat sed maecenas egestas semper.\"\u003c/font\u003e", 1]
		, [3, "Malcolm", "Johnson", 1673980940000, "\u003chtml\u003eUpdated status to \u003cb\u003eOpen\u003cb/\u003e", 1]
		, [4, "Lisa", "Longshot", 1674067340000, "Assigned \u003cb\u003eMelanie Brooker\u003c/b\u003e to ther Work Order", 1]
		, [5, "Bob", "Makerman", 1674748139000, "Set the \u003cb\u003ePriority\u003c/b\u003e to Urgent", 1]
		, [9, "Ray", "Sensenbach", 1675102512013, "\u003cb\u003eCreated\u003c/b\u003e the Work Order", 4]
		, [10, "Ray", "Sensenbach", 1675102526808, "\u003cb\u003eCreated\u003c/b\u003e the Work Order", 6]
		, [11, "Ray", "Sensenbach", 1675102556178, "\u003cb\u003eCompleted\u003c/b\u003e the Work Order", 1]
		, [12, "Ray", "Sensenbach", 1675102567976, "\u003cb\u003eCreated\u003c/b\u003e the Work Order", 2]
		, [13, "Ray", "Sensenbach", 1675102581732, "\u003cb\u003eCreated\u003c/b\u003e the Work Order", 22]
		, [14, "Ray", "Sensenbach", 1675102599447, "\u003cb\u003eCreated\u003c/b\u003e the Work Order", 7]
		]
	