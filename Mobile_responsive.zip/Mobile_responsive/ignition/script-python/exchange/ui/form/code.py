from exchange.ui import usr

def submitWorkOrder(name, requestor, location, description, asset, completionDate):
	"""Submit a new work order into the database"""
	nQuery = 'Exchange/UI Webinar/Insert Into/Insert Workorder'
	author = system.user.getUser('default', requestor)
	author_role = author.getRoles()
	assignee = usr.getRandomUser()
	params = {
		'create_date': system.date.now()
		, 'due_date': completionDate
		, 'location': location
		, 'last_name': assignee.get('lastname')
		, 'first_name': assignee.get('firstname')
		, 'description': description
		, 'name': name
		, 'asset_id': asset
		, 'priority': 'High'
		, 'status_id': 5 # Status = Not Started initially
		, 'author_firstname': author.get('firstname')
		, 'author_lastname': author.get('lastname')
		, 'role': author_role[0] if author_role else 'No Role Specified'
	}
	result = system.db.runNamedQuery(nQuery, params)
	return result