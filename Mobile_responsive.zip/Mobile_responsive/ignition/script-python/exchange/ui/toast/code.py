def make(message="Status updated to 'Closed'", showUndo=True, momento={}):
	"""Create a toast message using a message handler"""
	payload = {'message': message, 'active': True, 'show': {'undo': showUndo}, 'momento': momento}
	system.perspective.sendMessage('make-toast', payload)
	return None
	
def remove():
	"""Remove the current toast message"""
	payload = {}
	system.perspective.sendMessage('remove-toast', payload)
	return None