from exchange.ui import util

def menuTable():
	"""Run the Navigation Menu Named Query"""
	nQuery, params = 'Exchange/UI Webinar/Select/Navigation Menu', {}
	results = system.db.runNamedQuery(nQuery)
	return util.datasetToDict(results)
	
def shortcutTable():
	"""Run the Shortcut Menu Named Query"""
	nQuery, params = 'Exchange/UI Webinar/Select/Home Shortcuts', {}
	results = system.db.runNamedQuery(nQuery)
	return util.datasetToDict(results)
	
def updateAssetDeletedStatus(_id, is_deleted):
	"""Update an assets is_deleted property"""
	nQuery = 'Exchange/UI Webinar/Update/Asset is Deleted'
	params = {'id': _id, 'is_deleted': is_deleted}
	return system.db.runNamedQuery(nQuery, params)
	
def deleteAsset(_id):
	"""Delete asset"""
	return updateAssetDeletedStatus(_id, 1)
	
def unDeleteAsset(_id):
	"""Un-Delete asset"""
	return updateAssetDeletedStatus(_id, 0)